package com.example.demo.sell;


import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import com.example.demo.inventory.Inventory;

public class SellDao {
	private JdbcTemplate jdbcTemplate;
	
	public SellDao(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	//재품 전체 조회
	public List<Sell> selectAll() {
		List<Sell>results = jdbcTemplate.query("select * from INVENTORY", 
				new RowMapper<Sell>() {
					@Override
					public Sell mapRow(ResultSet rs, int rowNum)throws SQLException{
						Sell sell = new Sell(
									rs.getString("ID"),
									rs.getString("NAME"),
									rs.getInt("price"),
									rs.getInt("count")
									);
						return sell;
					}
		});
		return results;
	}
	//재품 ID 검색(Sell)
	public Sell SellSelectByID(String ID) {
		List<Sell>results = jdbcTemplate.query("select * from INVENTORY where ID =?", 
				new RowMapper<Sell>() {
					@Override
					public Sell mapRow(ResultSet rs, int rowNum)throws SQLException{
						Sell sell = new Sell(
									rs.getString("ID"),
									rs.getString("NAME"),
									rs.getInt("price"),
									rs.getInt("count")
									);
						return sell;
					}
		},ID);
		return results.isEmpty()?null:results.get(0);
	}
	//재품 ID 검색(인벤토리)
	public Inventory InventorySelectByID(String ID) {
		List<Inventory>results = jdbcTemplate.query("select * from INVENTORY where ID =?", 
				new RowMapper<Inventory>() {
					@Override
					public Inventory mapRow(ResultSet rs, int rowNum)throws SQLException{
						Inventory inventory = new Inventory(
									rs.getString("ID"),
									rs.getString("NAME"),
									rs.getInt("price"),
									rs.getInt("count")
									);
						return inventory;
					}
		},ID);
		return results.isEmpty()?null:results.get(0);
	}
	
	//제품 구매시 제품 재고 -
	public void ItemCountMinus(Inventory inventory) {
		jdbcTemplate.update("update INVENTORY set COUNT=? where ID=? ",inventory.getCount(),inventory.getID());
	}
}
