package com.example.demo.sell;

import com.example.demo.inventory.Inventory;

public class SellFunctionService {
	private SellDao sellDao;
	
	public SellFunctionService(SellDao sellDao) {
		this.sellDao=sellDao;
	}
	
	public int itemCountMinus(Sell req){
		Inventory inventory = sellDao.InventorySelectByID(req.getID());
		
		if((inventory.getCount()-req.getCount()) < 0) {
			return (inventory.getCount()-req.getCount());
		}
		
		Inventory modifyCountInventory = new Inventory(
			req.getID(),
			req.getName(),
			req.getPrice(),
			inventory.getCount()-req.getCount()
		);
		sellDao.ItemCountMinus(modifyCountInventory);
		
		return 1;
	}
}
