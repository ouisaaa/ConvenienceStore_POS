package com.example.demo.statistics;

import java.util.ArrayList;
import java.util.List;

public class StatisticsCountMaxService {
	private StatisticsDao statisticsDao;
	
	public StatisticsCountMaxService(StatisticsDao statisticsDao) {
		this.statisticsDao=statisticsDao;
	}
	
	public List<StatisticsCountMaxRequest> countMax() {
		List<StatisticsCountMaxRequest> IDs = statisticsDao.ItemSelectALLID();

		List<StatisticsCountMaxRequest> maxID = new ArrayList<>();
		
		int maxCount=0;
		for(int i=0;i<IDs.size();i++) {
			List<StatisticsCountMaxRequest> SumCount = statisticsDao.ItemSelectCountSumByID(IDs.get(i));
			if(maxCount<SumCount.get(0).getCount()) {
				maxCount=SumCount.get(0).getCount();	
				maxID.clear();
				maxID.add(SumCount.get(0));
			}
			else if(maxCount==SumCount.get(0).getCount()) { 
				maxID.add(SumCount.get(0));
			}
		}
		return maxID;
	}
	
}
