package com.example.demo.statistics;

public class StatisticsCountMaxRequest {
	private String ID;
	private String name;
	private int count;
	
	public StatisticsCountMaxRequest(String ID, String name,int count) {
		this.ID=ID;
		this.name=name;
		this.count=count;
	}

	public String getID() {
		return ID;
	}

	public void setID(String iD) {
		ID = iD;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
