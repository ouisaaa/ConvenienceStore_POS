package com.example.demo.statistics;

import java.time.LocalDateTime;

import com.example.demo.inventory.Inventory;
import com.example.demo.sell.Sell;
import com.example.demo.sell.SellDao;


public class StatisticsRegisterService {
	private StatisticsDao statisticsDao;
	
	public StatisticsRegisterService(StatisticsDao statisticsDao) {
		this.statisticsDao=statisticsDao;
	}
	
	public void regist(Sell req){
		Statistics newSregReq = new Statistics(
					req.getID(),
					req.getName(),
					req.getPrice(),
					req.getCount(),
					(req.getPrice()*req.getCount()),
					LocalDateTime.now()
		);
		statisticsDao.insert(newSregReq);
		
	}
}
