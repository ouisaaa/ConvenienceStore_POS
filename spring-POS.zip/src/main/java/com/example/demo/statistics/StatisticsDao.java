package com.example.demo.statistics;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;

import com.example.demo.receiving.Receiving;
import com.example.demo.sell.Sell;

public class StatisticsDao {
	private JdbcTemplate jdbcTemplate;
	
	public StatisticsDao(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	//재품 전체 조회
	public List<Statistics> selectAll() {
		List<Statistics>results = jdbcTemplate.query("select * from STATISTICS", 
				new RowMapper<Statistics>() {
					@Override
					public Statistics mapRow(ResultSet rs, int rowNum)throws SQLException{
						Statistics statistics = new Statistics(
									rs.getString("ID"),
									rs.getString("NAME"),
									rs.getInt("price"),
									rs.getInt("count"),
									rs.getInt("sellPrice"),
									rs.getTimestamp("sellDate").toLocalDateTime()
									);
						return statistics;
					}
		});
		return results;
	}
	//재품ID 전체 조회
	public List<StatisticsCountMaxRequest> ItemSelectALLID() {
		List<StatisticsCountMaxRequest>results = jdbcTemplate.query("select ID,name,count  from Inventory", 
				new RowMapper<StatisticsCountMaxRequest>() {
					@Override
					public StatisticsCountMaxRequest mapRow(ResultSet rs, int rowNum)throws SQLException{
						StatisticsCountMaxRequest statisticsCountMaxRequest= new StatisticsCountMaxRequest(
									rs.getString("ID"),
									rs.getString("name"),
									rs.getInt("count")
								);
						
						return statisticsCountMaxRequest;
					}
		});
		return results;
	}
	//재품ID를 통해 통계 창 count 조회
	public List<StatisticsCountMaxRequest> ItemSelectCountSumByID(StatisticsCountMaxRequest Sreq) {
		List<StatisticsCountMaxRequest>results = jdbcTemplate.query("SELECT SUM(count) AS count FROM statistics WHERE id =?",
				new RowMapper<StatisticsCountMaxRequest>() {
					@Override
					public StatisticsCountMaxRequest mapRow(ResultSet rs, int rowNum)throws SQLException{
						StatisticsCountMaxRequest statisticsCountMaxRequest;
						if(rs.getObject("COUNT") == null) {
							statisticsCountMaxRequest = new StatisticsCountMaxRequest(
									Sreq.getID(),
									Sreq.getName(),
									0
							);
						}else {
							statisticsCountMaxRequest = new StatisticsCountMaxRequest(
										Sreq.getID(),
										Sreq.getName(),
										rs.getInt("count")
								);
						}
						return statisticsCountMaxRequest;
					}
		},Sreq.getID());
		return results;
	}
	//재품ID 통한 price 전체 조회
	public int ItemSelectPrice(String ID) {
		int results = jdbcTemplate.queryForObject("select PRICE from Inventory where ID=?", 
				new RowMapper<Integer>() {
					@Override
					public Integer mapRow(ResultSet rs, int rowNum)throws SQLException{
						int price=rs.getInt("PRICE");
						return price;
					}
		},ID);
		return results;
	}
	//월별 통계 구하기
	public List<Statistics> MonthSelectAll(String year, String month) {
		List<Statistics>results = jdbcTemplate.query("select * from STATISTICS where year(sellDate)=? and month(sellDate)=?",
				new RowMapper<Statistics>() {
					@Override
					public Statistics mapRow(ResultSet rs, int rowNum)throws SQLException{
						Statistics statistics = new Statistics(
									rs.getString("ID"),
									rs.getString("NAME"),
									rs.getInt("price"),
									rs.getInt("count"),
									rs.getInt("sellPrice"),
									rs.getTimestamp("sellDate").toLocalDateTime()
									);
						return statistics;
					}
		},year,month);
		return results;
	}
	//주간 통계 구하기
	public List<Statistics> WeekSelectAll(String week) {
		List<Statistics>results = jdbcTemplate.query("select * from STATISTICS where yearweek(sellDate)=?",
				new RowMapper<Statistics>() {
					@Override
					public Statistics mapRow(ResultSet rs, int rowNum)throws SQLException{
						Statistics statistics = new Statistics(
									rs.getString("ID"),
									rs.getString("NAME"),
									rs.getInt("price"),
									rs.getInt("count"),
									rs.getInt("sellPrice"),
									rs.getTimestamp("sellDate").toLocalDateTime()
									);
						return statistics;
					}
		},week);
		return results;
	}
	//일별 통계 구하기
	public List<Statistics> DateSelectAll(LocalDate date) {
		List<Statistics>results = jdbcTemplate.query("select * from STATISTICS where date(sellDate)=?",
				new RowMapper<Statistics>() {
					@Override
					public Statistics mapRow(ResultSet rs, int rowNum)throws SQLException{
						Statistics statistics = new Statistics(
									rs.getString("ID"),
									rs.getString("NAME"),
									rs.getInt("price"),
									rs.getInt("count"),
									rs.getInt("sellPrice"),
									rs.getTimestamp("sellDate").toLocalDateTime()
									);
						return statistics;
					}
		},date);
		return results;
	}
	//insert 통계 내역 추가
	public void insert(Statistics sell) {
		KeyHolder keyHolder = new GeneratedKeyHolder();
		jdbcTemplate.update(
			new PreparedStatementCreator() {
			@Override
			public PreparedStatement createPreparedStatement(Connection con)throws SQLException{
				PreparedStatement pstmt = con.prepareStatement("insert into STATISTICS (ID, NAME, PRICE, COUNT, SELLPRICE, SELLDATE) values (?, ?, ?, ?, ?, ?)", Statement.RETURN_GENERATED_KEYS);
				pstmt.setString(1, sell.getID());
				pstmt.setString(2, sell.getName());
				pstmt.setInt(3, sell.getPrice());
				pstmt.setInt(4, sell.getCount());
				pstmt.setInt(5, sell.getSellPrice());
				pstmt.setObject(6, sell.getSellDate());
				
				return pstmt;
			}
		},keyHolder );
	}
}
