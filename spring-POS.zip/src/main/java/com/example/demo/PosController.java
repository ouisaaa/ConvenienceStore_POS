package com.example.demo;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.Worker.Worker;
import com.example.demo.Worker.WorkerDao;
import com.example.demo.Worker.WorkerDeleteService;
import com.example.demo.Worker.WorkerModifyService;
import com.example.demo.Worker.WorkerRegisterRequest;
import com.example.demo.Worker.WorkerRegisterService;
import com.example.demo.inventory.Inventory;
import com.example.demo.inventory.InventoryDao;
import com.example.demo.inventory.InventoryModifyService;
import com.example.demo.inventory.InventoryReceivingItemService;
import com.example.demo.inventory.InventoryRegisterRequest;
import com.example.demo.inventory.InventoryRegisterService;
import com.example.demo.receiving.Receiving;
import com.example.demo.receiving.ReceivingDao;
import com.example.demo.receiving.ReceivingRegisterService;
import com.example.demo.receiving.ReceivingSearchService;
import com.example.demo.sell.Sell;
import com.example.demo.sell.SellDao;
import com.example.demo.sell.SellFunctionService;
import com.example.demo.sell.SellSearchService;
import com.example.demo.statistics.StatisticsRegisterService;
import com.example.demo.statistics.Statistics;
import com.example.demo.statistics.StatisticsCountMaxRequest;
import com.example.demo.statistics.StatisticsCountMaxService;
import com.example.demo.statistics.StatisticsDao;

@Controller
public class PosController {
	//직원 관리 기능
	@Autowired
	private WorkerDao workerDao;
	@Autowired
	private WorkerRegisterService workerRegisterService;
	@Autowired
	private WorkerModifyService workerModifyService;

	
	//재품 관리 기능
	@Autowired
	private InventoryDao inventoryDao;
	@Autowired
	private InventoryRegisterService inventoryRegisterService;
	@Autowired
	private InventoryModifyService inventoryModifyService;
	@Autowired
	private InventoryReceivingItemService inventoryReceivingItemService;
	//입고 관리 기능
	@Autowired
	private ReceivingDao receivingDao;
	@Autowired
	private ReceivingRegisterService receivingRegisterService;
	@Autowired
	private ReceivingSearchService receivingSearchService;
	//판매 기능
	@Autowired
	private SellDao sellDao;
	@Autowired
	private SellSearchService sellSearchService;
	@Autowired
	private SellFunctionService sellFunctionService;
	//통계 기능
	@Autowired
	private StatisticsDao statisticsDao;
	@Autowired
	private StatisticsRegisterService statisticsRegisterService;
	@Autowired
	private StatisticsCountMaxService statisticsCountMaxService;
	
	//매인화면
	@RequestMapping({"/","/main"})
	public String main() {return "main";}
	
	/******직원 관리 핸들러*********/
	//직원 관리 창
	@RequestMapping(value="/worker/worker_option",method=RequestMethod.POST)
	public String handleWorker(Model model) {
		List<Worker> workerList = workerDao.selectAll();
		model.addAttribute("workers",workerList);
		return "worker/worker_option";
	}
	//직원 등록 누를시
	@RequestMapping(value="/worker/register_worker",method=RequestMethod.POST)
	public String handleRegisterWorker(Model model) {
		model.addAttribute("registerRequeset", new WorkerRegisterRequest());
		
		return "worker/register_worker";
	}
	//직원 등록 기입 사항
	@RequestMapping(value="/worker/register_success",method=RequestMethod.POST)
	public String handleRegisterSuccess(WorkerRegisterRequest WregReq,Model model) {
		try {
			workerRegisterService.regist(WregReq);
			model.addAttribute("worker", WregReq);
			
			return "/worker/register_success";
		} catch(Exception e) {
			model.addAttribute("error",e.getMessage());
			return "/worker/register_fail";
		}
		
	}
	
	//정보 수정 
	@RequestMapping(value="/worker/modify_worker",method=RequestMethod.POST)
	public String handleModify(Worker worker, Model model) {
		model.addAttribute("worker",worker);
		return "/worker/modify_worker";
	}
	//정보 수정 적용
	@RequestMapping(value="/worker/modify_success",method=RequestMethod.POST)
	public String handleModifySuccess(Worker WregReq, Model model) {
			workerModifyService.modify(WregReq);
			model.addAttribute("worker", WregReq);
			
			return "/worker/modify_success";
	}
	//직원 정보 삭제 여부 확인
	@RequestMapping(value="/worker/delete_agreement",method=RequestMethod.POST)
	public String handleDelete_agreement(Worker worker, Model model) {
		model.addAttribute("worker",worker);
		
		return "/worker/delete_agreement";
	}
	//직원 정보 삭제
	@RequestMapping(value="/worker/delete_success",method=RequestMethod.POST)
	public String handleDelete(Worker worker, Model model) {
			workerDao.delete(worker.getID());
			model.addAttribute("worker",worker);
			
			return "/worker/delete_success";
	}
	/*********************************************************************************/
	/***************************재고 관리 핸들러*******************************************/
	//재고 관리 페이지
	@RequestMapping({"/inventory/inventory_management"})
	public String handleInventory(Model model) {
		List<Inventory> inventoryList = inventoryDao.selectAll();
		model.addAttribute("items",inventoryList);
		return "/inventory/inventory_management";
	}
	//신규 물품 등록 
	@RequestMapping(value="/inventory/register_item",method=RequestMethod.POST)
	public String handleRegisterItem(Model model) {
		model.addAttribute("registerRequest",new InventoryRegisterRequest());
		
		return "/inventory/register_item";
	}
	//신규 물품 등록 적용 
	@RequestMapping(value="/inventory/register_success",method=RequestMethod.POST)
	public String handleRegisterSuccess(InventoryRegisterRequest IregReq, Model model) {
		try {
			inventoryRegisterService.regist(IregReq);
			receivingRegisterService.regist(IregReq);
			model.addAttribute("inventory", IregReq);
			
			return "/inventory/register_success";
		} catch(Exception e) {
			model.addAttribute("error",e.getMessage());
			return "/inventory/register_fail";
		}
	}
	//입고 기능
	@RequestMapping(value="/inventory/receiving_item", method=RequestMethod.POST)
	public String handleReceivingItem(Inventory inventory, Model model) {
		model.addAttribute("inventory",inventory);
		return "/inventory/receiving_item";
	}
	//입고 기능
	@RequestMapping(value="/inventory/receiving_success", method=RequestMethod.POST)
	public String handleReceivingSuccess(InventoryRegisterRequest IregReq, Model model) {
		try {
			inventoryReceivingItemService.receiving(IregReq);
			receivingRegisterService.regist(IregReq);
			model.addAttribute("inventory",IregReq);
			return "/inventory/receiving_success";
		} catch (Exception e) {
			model.addAttribute("error",e.getMessage());
			return "/inventory/receiving_fail";
		}
	}
	//정보 수정 
	@RequestMapping(value="/inventory/modify_item",method=RequestMethod.POST)
	public String handleModifyItem(Inventory inventory, Model model) {
		model.addAttribute("inventory",inventory);
		return "/inventory/modify_item";
	}
	//정보 수정 적용
	@RequestMapping(value="/inventory/modify_success",method=RequestMethod.POST)
	public String handleModifyItemSuccess(Inventory Inventory,Model model) {
			inventoryModifyService.modify(Inventory);
			model.addAttribute("inventory", Inventory);
			
			return "/inventory/modify_success";
	}
	//정보 삭제 여부 확인
	@RequestMapping(value="/inventory/delete_agreement",method=RequestMethod.POST)
	public String handleDeleteItemAgreement(Inventory inventory, Model model) {
		model.addAttribute("inventory",inventory);
		
		return "/inventory/delete_agreement";
	}
	//정보 삭제
	@RequestMapping(value="/inventory/delete_success",method=RequestMethod.POST)
	public String handleDeleteItem(Inventory inventory, Model model) {
			inventoryDao.delete(inventory);
			model.addAttribute("inventory",inventory);
			return "/inventory/delete_success";
	}
	/*********************************************************************************/
	/***************************입고 관리 핸들러*******************************************/
	//입고 관리 페이지
	@RequestMapping(value="/receiving/receiving_item_list",method=RequestMethod.POST)
	public String handleReceivingList(Model model) {
		List<Receiving> receivingList = receivingDao.ItemSelectAll();
		model.addAttribute("items",receivingList);
		
		return "/receiving/receiving_item_list";
	}
	//입고 물품 기록
	@RequestMapping(value="/receiving/receiving_search",method=RequestMethod.POST)
	public String handleReceivingSearch(
			@RequestParam("start_date") @DateTimeFormat(pattern="yyyy-MM-dd") LocalDate start_date,
			@RequestParam("end_date")@DateTimeFormat(pattern="yyyy-MM-dd") LocalDate end_date,
			Model model) {
		List<Receiving> receivingList = receivingSearchService.search(start_date, end_date);
		model.addAttribute("start_date",start_date);
		model.addAttribute("end_date",end_date);
		
		model.addAttribute("items",receivingList);
		
		return "/receiving/receiving_searchItem";
	}	
	/*********************************************************************************/
	/***************************판매 관리 핸들러*******************************************/
	//판매 기능 페이지
	@RequestMapping({"/sell/sell_management"})
	public String handleSell() {return "/sell/sell_management";}
	//물품 검색 기능
	List<Sell> wishList=new ArrayList<>();
	@RequestMapping(value="/sell/sell_search",method=RequestMethod.POST)
	public String handleSellSearch(String search, Model model) {
		try {
			wishList.add(sellSearchService.search(search));
			model.addAttribute("items",wishList);
			return "/sell/sell_management";
		}catch(Exception e) {
			model.addAttribute("error",e.getMessage());
			return "/sell/sell_search_fail";
		}
	}
	
	//장바구니 초기화
	@RequestMapping(value="/sell/reset",method=RequestMethod.POST)
	public String handleSellResetList(Model model) {
		wishList.clear();
		model.addAttribute("items",wishList);
		return "/sell/sell_management";
	}
	//구매 요청 시 wishList안에 물품과 개수를 계산하여 총 금액 알려줌
	@RequestMapping(value="/sell/sell_agreement",method=RequestMethod.POST)
	public String handleSellAgreement(Model model) {
		int totalPrice=0;
		ArrayList<String> str= new ArrayList<>();
		
		for(int i=0;i<wishList.size();i++) {
			if(sellFunctionService.itemCountMinus(wishList.get(i))<0) {
				//구매시 현재 있는 물품수 보다 구매 수를 높게 잡을시 구매할수없음을 확인하는 코드
				str.add("상품 ID: "+ wishList.get(i).getID() + " 이름: " + wishList.get(i).getName());
			}
			totalPrice+=(wishList.get(i).getPrice()*wishList.get(i).getCount());
		}
		
		if(str.size()<1) {
			model.addAttribute("totalPrice",totalPrice);
			return "/sell/sell_agreement";
		}
		else {
			model.addAttribute("fails",str);
			return "/sell/sell_fail";
		}
	}
	//statistics 테이블에 추가(판매내역 테이블)
	@RequestMapping(value="/sell/sell_success",method=RequestMethod.POST)
	public String handleSellSuccess() {
		for(int i=0;i<wishList.size();i++) {
			statisticsRegisterService.regist(wishList.get(i));
		}
		
		wishList.clear();
		return "/sell/sell_success";
	}
	//수량 수정-증가
	@RequestMapping(value="/sell/sell_countModifyPlus")
	public String handleSellCountModifyPlus(@RequestParam("clone_index") int index,Model model) {
		wishList.get(index-1).setCount(wishList.get(index-1).getCount()+1);
		model.addAttribute("items",wishList);
		return "/sell/sell_management";
	}
	//수량 수정-감소
	@RequestMapping(value="/sell/sell_countModifyMinus")
	public String handleSellCountModifyMinus(@RequestParam("clone_index") int index,Model model) {
		if(wishList.get(index-1).getCount()==1) {
			wishList.remove(index-1);
			}else { 
			wishList.get(index-1).setCount(wishList.get(index-1).getCount()-1);
		}
		model.addAttribute("items",wishList);
		
		return "/sell/sell_management";
	}
	/*********************************************************************************/
	/***************************통계 관리 핸들러*******************************************/	
	//통계 관리 페이지-기본적으로 전체 매출이 나올수있도록
	@RequestMapping({"/statistics/statistics"})
	public String handleStatistic(Model model) {
		List<Statistics> statisticsList = statisticsDao.selectAll();
		List<StatisticsCountMaxRequest> maxID =statisticsCountMaxService.countMax();
		
		model.addAttribute("items",statisticsList);
		model.addAttribute("maxID",maxID);
		return "/statistics/statistics";
	}
	//월간 통계 기능
	@RequestMapping(value="/statistics/statistics_month",method=RequestMethod.POST)
	public String handleStatisticMonth(
			@RequestParam("month") String month,
			Model model) {
		String[] yearmonth = month.split("-");
		List<Statistics> statisticsList = statisticsDao.MonthSelectAll(yearmonth[0],yearmonth[1]);
		List<StatisticsCountMaxRequest> maxID =statisticsCountMaxService.countMax();
		
		model.addAttribute("month",month);
		model.addAttribute("items",statisticsList);
		model.addAttribute("maxID",maxID);
		return "/statistics/statistics_month";
	}
	//주간 통계 기능
	@RequestMapping(value="/statistics/statistics_week",method=RequestMethod.POST)
	public String handleStatisticWeek(
			@RequestParam("week") String week,
			Model model) {
		week=week.replace("-W", "");
		//input으로 넘어오는 형태는 YYYY-Www형식임으로 -W를 제거 함으로 DB 검색을 할수있게
		
		List<Statistics> statisticsList = statisticsDao.WeekSelectAll(week);
		List<StatisticsCountMaxRequest> maxID =statisticsCountMaxService.countMax();

		model.addAttribute("week",week);
		model.addAttribute("items",statisticsList);
		model.addAttribute("maxID",maxID);
		return "/statistics/statistics_week";
	}
	//일간 통계 기능
	@RequestMapping(value="/statistics/statistics_date",method=RequestMethod.POST)
	public String handleStatisticDate(
			@RequestParam("date") LocalDate date,
			Model model) {
		List<Statistics> statisticsList = statisticsDao.DateSelectAll(date);
		List<StatisticsCountMaxRequest> maxID =statisticsCountMaxService.countMax();
		

		model.addAttribute("date",date);
		model.addAttribute("items",statisticsList);
		model.addAttribute("maxID",maxID);
		return "/statistics/statistics_date";
	}
	/*********************************************************************************/

}
