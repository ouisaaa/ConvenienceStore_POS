package com.example.demo.inventory;

public class InventoryModifyService {
	private InventoryDao inventoryDao;
	
	public InventoryModifyService(InventoryDao inventoryDao) {
		this.inventoryDao=inventoryDao;
	}
	public void modify(Inventory req){
		Inventory modifyInventory = new Inventory(
				req.getID(),
				req.getName(),
				req.getPrice(),
				req.getCount()
		);
		inventoryDao.update(modifyInventory);
	}
	
}
