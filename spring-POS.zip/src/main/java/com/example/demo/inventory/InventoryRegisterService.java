package com.example.demo.inventory;

import java.time.LocalDateTime;

import com.example.demo.receiving.Receiving;

public class InventoryRegisterService {
	private InventoryDao inventoryDao;
	
	public InventoryRegisterService(InventoryDao inventoryDao) {
		this.inventoryDao=inventoryDao;
	}
	public void regist(InventoryRegisterRequest req) throws Exception{
		Inventory inventory = inventoryDao.selectByID(req.getID());
		
		if(inventory !=null) {
			throw new Exception("중복된 ID 입력입니다.");
		}
		Inventory newInventory = new Inventory(
					req.getID(),
					req.getName(),
					req.getPrice(),
					req.getCount()
		);
		inventoryDao.insert(newInventory);
	}
}
