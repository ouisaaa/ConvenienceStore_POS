package com.example.demo.inventory;

public class InventoryReceivingItemService {
	private InventoryDao inventoryDao;
	
	public  InventoryReceivingItemService(InventoryDao inventoryDao) {
		this.inventoryDao= inventoryDao;
	}
	public void receiving(InventoryRegisterRequest req) throws Exception{
		Inventory inventory = inventoryDao.selectByID(req.getID());
		
		if(req.getCount() <0) {
			throw new Exception("잘못된 입력: 입고 수량에 마이너스값이 들어갔습니다.");
		}
		if(inventory ==null) {
			throw new Exception("입력하신 ID와 동일한 물품을 찾지 못했습니다. 입력을 다시 확인해주세요");
		}
		
		Inventory receivingInventory = new Inventory(
				req.getID(),
				req.getName(),
				req.getPrice(),
				inventory.getCount()+req.getCount()
		);
		inventoryDao.update(receivingInventory);
		
	}
}
