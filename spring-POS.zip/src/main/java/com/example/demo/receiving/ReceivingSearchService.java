package com.example.demo.receiving;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

public class ReceivingSearchService {
	private ReceivingDao receivingDao;
	
	public ReceivingSearchService(ReceivingDao receivingDao) {
		this.receivingDao=receivingDao;
	}
	public List<Receiving> search(LocalDate start_date, LocalDate end_date) {
		LocalDateTime start_datetime = start_date.atStartOfDay();
		LocalDateTime end_datetime = end_date.atTime(23,59,59);
		
		return receivingDao.DateSelectAll(start_datetime, end_datetime);
	}
}
