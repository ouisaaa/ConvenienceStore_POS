package com.example.demo.receiving;

import java.time.LocalDateTime;

public class Receiving {
	private String ID;
	private String name;
	private int price;
	private int count;
	private LocalDateTime receiving_date;
	
	public Receiving(String ID, String  name, int price, int count, LocalDateTime receiving_date) {
		this.ID=ID;
		this.name=name;
		this.price=price;
		this.count=count;
		this.receiving_date=receiving_date;
	}

	public String getID() {
		return ID;
	}

	public void setID(String iD) {
		ID = iD;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public LocalDateTime getReceiving_date() {
		return receiving_date;
	}

	public void setReceiving_date(LocalDateTime receiving_date) {
		this.receiving_date = receiving_date;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}
}
