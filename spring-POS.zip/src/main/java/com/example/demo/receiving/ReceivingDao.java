package com.example.demo.receiving;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;



public class ReceivingDao {
	private JdbcTemplate jdbcTemplate;
	
	public ReceivingDao(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	//재품 전체 조회
	public List<Receiving> ItemSelectAll() {
		List<Receiving>results = jdbcTemplate.query("select * from RECEIVING", 
				new RowMapper<Receiving>() {
					@Override
					public Receiving mapRow(ResultSet rs, int rowNum)throws SQLException{
						Receiving receiving = new Receiving(
									rs.getString("ID"),
									rs.getString("NAME"),
									rs.getInt("price"),
									rs.getInt("count"),
									rs.getTimestamp("receiving_date").toLocalDateTime()
									);
						return receiving;
					}
		});
		return results;
	}
	//입고 날짜 구하기
	public List<Receiving> DateSelectAll(LocalDateTime start_date, LocalDateTime end_date) {
		String queryStr = "between '"+ start_date +"' and '" + end_date+"'";
		System.out.println(queryStr);
		List<Receiving>results = jdbcTemplate.query("select * from RECEIVING where RECEIVING_DATE "+queryStr,
				new RowMapper<Receiving>() {
					@Override
					public Receiving mapRow(ResultSet rs, int rowNum)throws SQLException{
						Receiving receiving = new Receiving(
									rs.getString("ID"),
									rs.getString("NAME"),
									rs.getInt("price"),
									rs.getInt("count"),
									rs.getTimestamp("receiving_date").toLocalDateTime()
									);
						return receiving;
					}
		});
		return results;
	}
	//insert 새로운 입고기록 등록
	public void Insert(Receiving receiving) {
		KeyHolder keyHolder = new GeneratedKeyHolder();
		jdbcTemplate.update(
			new PreparedStatementCreator() {
			@Override
			public PreparedStatement createPreparedStatement(Connection con)throws SQLException{
				PreparedStatement pstmt = con.prepareStatement("insert into RECEIVING (ID, NAME, PRICE,COUNT, RECEIVING_DATE) values (?, ?, ?, ?, ?)", Statement.RETURN_GENERATED_KEYS);
				pstmt.setString(1, receiving.getID());
				pstmt.setString(2, receiving.getName());
				pstmt.setInt(3, receiving.getPrice());
				pstmt.setInt(4, receiving.getCount());
				pstmt.setObject(5, receiving.getReceiving_date());
				
				return pstmt;
			}
		},keyHolder );
	}
}
