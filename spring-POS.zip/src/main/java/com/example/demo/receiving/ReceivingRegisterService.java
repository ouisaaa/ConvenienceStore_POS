package com.example.demo.receiving;

import java.time.LocalDateTime;

import com.example.demo.inventory.Inventory;
import com.example.demo.inventory.InventoryRegisterRequest;

public class ReceivingRegisterService {
	private ReceivingDao receivingDao;
	
	public ReceivingRegisterService(ReceivingDao receivingDao) {
		this.receivingDao=receivingDao;
	}
	
	public void regist(InventoryRegisterRequest req){
		Receiving newReceiving = new Receiving(
					req.getID(),
					req.getName(),
					req.getPrice(),
					req.getCount(),
					LocalDateTime.now()
				);
		receivingDao.Insert(newReceiving);
	}
}
