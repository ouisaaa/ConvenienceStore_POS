package com.example.demo.Worker;

import java.time.LocalDateTime;

public class WorkerRegisterService {
	private WorkerDao workerDao;
	
	public WorkerRegisterService(WorkerDao workerDao) {
		this.workerDao = workerDao;
	}
	
	//신규 직원 등록
	public void regist(WorkerRegisterRequest req) throws Exception {
		Worker worker = workerDao.selectByID(req.getID());
		
		if(worker !=null) {
			throw new Exception("중복된 ID 값");
		}
		Worker newWorker = new Worker(
				req.getID(),
				req.getPassword(),
				req.getName(),
				LocalDateTime.now(),
				req.getTitle()
		);
		workerDao.insert(newWorker);
		
	}
}
