package com.example.demo.Worker;

import java.time.LocalDateTime;

public class WorkerModifyService {
	private WorkerDao workerDao;
	
	public WorkerModifyService(WorkerDao workerDao) {
		this.workerDao = workerDao;
	}
	
	public void modify(Worker req){
		Worker modifyWorker= new Worker(
			req.getID(),
			req.getPassword(),
			req.getName(),
			LocalDateTime.now(),
			req.getTitle()
		);
		workerDao.update(modifyWorker);
		
	} 
	
}
